package com.niit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.niit.dao.UserDao;
import com.niit.model.User;

@RestController
public class UserController {

	@Autowired
	UserDao userDao;

	@CrossOrigin(origins = "http://localhost:8045")
	@PostMapping(value = "/login")
	public ResponseEntity<User> checkLogin(@RequestBody User user) {
		if (userDao.checkLogin(user)) {
			User tempUser = (User) userDao.getUserByName(user.getUsername());
			userDao.updateOnlineStatus("online", tempUser);
			System.out.println("**********done*********");
			System.out.println(tempUser.getUsername());
			return new ResponseEntity<User>(tempUser, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(user, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/registerUser")
	public ResponseEntity<String> registerUser(@RequestBody User user) {

		user.setRole("USER");
		if (userDao.registerUser(user)) {
			return new ResponseEntity<String>("User Registered Successfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("User registration failed", HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping(value = "/updateUser/{username}")
	public ResponseEntity<String> updateUser(@PathVariable("username") String username, @RequestBody User user) {
		System.out.println("updating user " + username);
		User uUser = userDao.getUser(47);
		if (uUser == null) {
			System.out.println("No user found " + username);
			return new ResponseEntity<String>("No user found", HttpStatus.NOT_FOUND);
		}
		uUser.setUsername(user.getUsername());
		System.out.println(user.getUsername());
		userDao.updateUser(uUser);
		return new ResponseEntity<String>("User updated successfully", HttpStatus.OK);
	}

	@GetMapping(value = "/listUsers")
	public ResponseEntity<List<User>> listUsers() {
		List<User> listUsers = userDao.listUsers();
		if (listUsers.size() != 0) {
			return new ResponseEntity<List<User>>(listUsers, HttpStatus.OK);
		}
		return new ResponseEntity<List<User>>(listUsers, HttpStatus.NOT_FOUND);
	}

	@GetMapping(value = "/getUser/{loginname}")
	public ResponseEntity<User> getUser(@PathVariable("loginname") String loginname) {
		User user = userDao.getUserByName(loginname);
		if (user == null) {
			System.out.println("No user found");
			return new ResponseEntity<User>(user, HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<User>(user, HttpStatus.OK);
		}
	}

	@DeleteMapping(value = "/deleteUser/{loginname}")
	public ResponseEntity<String> deleteUser(@PathVariable("loginname") String loginname) {
		System.out.println("In delete user" + loginname);
		User user = userDao.getUserByName(loginname);
		if (user == null) {
			System.out.println("No user with LoginName " + loginname + " found to delete");
			return new ResponseEntity<String>("No user found to delete", HttpStatus.NOT_FOUND);
		} else {
			userDao.deleteUser(user);
			return new ResponseEntity<String>("User with LoginName " + loginname + " deleted successfully",
					HttpStatus.OK);
		}
	}

}
