package com.niit.collaboration.Backend;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.BlogDao;
import com.niit.model.Blog;
import com.niit.model.BlogComment;

public class TestBlog {

	private static AnnotationConfigApplicationContext context;
	private static BlogDao blogdao;
	private Blog blog;
	private BlogComment blogComment;

	@BeforeClass
	public static void init() {

		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		blogdao = (BlogDao) context.getBean("blogdao");
		System.out.println("------init----");
	}

	@Test
	public void addBlogTest() {
		blog = new Blog();
		blog.setUsername("niit");
		blog.setStatus("A");
		blog.setCreateDate(new Date());
		blog.setBlogName("Connect");
		blog.setBlogContent("Review");
		System.out.println("add blog");

		blogComment = new BlogComment();
		String username = blog.getUsername();
		int blogId = blog.getBlogId();
		blogComment.setBlogId(blogId);
		blogComment.setUserName(username);
		blogComment.setCommentDate(new Date());
		blogComment.setCommentText("parents blog");
		List<BlogComment> blogComments = new ArrayList<BlogComment>();
		blogComments.add(blogComment);

		blog.setBlogComments(blogComments);
		assertEquals("Product Successfully added to the database", true, blogdao.addBlog(blog));

		System.out.println("<-----------Successfully added blogCommment-------->");

	}

	/*
	 * @Test public void testAddBlogComment() { blogComment = new BlogComment();
	 * blog = blogdao.getBlog(43); String username = blog.getUsername(); int blogId
	 * = blog.getBlogId(); blogComment.setBlogId(blogId);
	 * blogComment.setUserName(username); blogComment.setCommentDate(new Date());
	 * blogComment.setCommentText("parents blog");
	 * assertEquals("Successfully added the blogComment...", true,
	 * blogdao.addBlogComment(blogComment));
	 * System.out.println("<-----------Successfully added blogCommment-------->"); }
	 */
	/*
	 * @Test public void getBlogTest() { blog = new Blog(); blog.setBlogId(5);
	 * blog.setBlogName("abc"); blog.setBlogContent("123456");
	 * blog.setCreateDate(new Date()); blog.setUsername("xyz"); blog.setStatus("A");
	 * System.out.println("getting blog details"); Blog blog2 = blogdao.getBlog(5);
	 * assertNotNull("issue in data of blog" + blog2);
	 * System.out.println(blog2.getStatus() + blog2.getBlogName()); }
	 */

}
