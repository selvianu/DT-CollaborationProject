package com.niit.collaboration.Backend;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDao;
import com.niit.model.Job;
import com.niit.model.User;

public class TestUser {
	private static AnnotationConfigApplicationContext context;
	private static UserDao userdao;
	private User user;

	@BeforeClass
	public static void init() {

		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		userdao = (UserDao) context.getBean("userdao");
		System.out.println("------init userdao----");
	}

	/*
	 * @Test public void allUserTest() { user = new User(); List<User> allUsers =
	 * userdao.listUsers(); assertNotNull("no data" + allUsers); for (User user :
	 * allUsers) { System.out.println(user); } System.out.println("No of users:  " +
	 * allUsers.size()); }
	 */
	/*@Test
	public void GetUserByNameTest() {
		user = new User();
		User userByName = userdao.getUserByName("selvi");
		assertNotNull("data available" + userByName);
		System.out.println(userByName);
	}*/

	@Test
	public void addUserTest() {
		user = new User(); // user.setId(101);
		user.setUsername("selvi");
		user.setBirthDate(new Date());
		user.setEmailId("selvi@gmail.com");
		user.setEnabled(true);
		user.setFirstname("selvi");
		user.setGender('f');
		user.setLastname("vts");
		user.setPassword("123");
		user.setRole("user");
		user.setStatus("online");
		user.setUsername("selvi");

		System.out.println("add user");
		assertEquals("user added to DB", true, userdao.addUser(user));
	}

/*	@Test
	public void testGetUserByName() {
		System.out.println("^^^^^");
		// user = userdao.getUser(47);
		// System.out.println(user);
		User userByName = userdao.getUserByName("selvi");
		String name_user = userByName.toString();
		// System.out.println(userByName.toString());
		assertEquals(" is the table", "selvi", name_user);
		System.out.println("Success");
	}

	/*
	 * @Test public void deleteUserTest() { user = new User();
	 * System.out.println("deleting...."); user.setUserId(10);
	 * assertEquals("User deleted", true, userdao.deleteUser(user)); }
	 */

	/*
	 * @Test public void updateUserTest() { user = new User(); user.setUserId(14);
	 * user.setIsOnline('y'); assertEquals("User Details Updated", true,
	 * userdao.updateUser(user)); }
	 */

	/*
	 * @Test public void checkLoginTest() { System.out.println("checking login");
	 * user = new User(); user.setUsername("selvi"); user.setPassword("123");
	 * assertTrue("Checking user", userdao.checkLogin(user));
	 * 
	 * }
	 */

	/*
	 * @Ignore
	 * 
	 * @Test public void updateOnlineStatusTest() { User user2 =
	 * userdao.getUser("selvi"); assertTrue("Problem in updating status",
	 * userdao.updateOnlineStatus("online", user2));
	 * System.out.println("<============Updated the online status============>"); }
	 */

}
