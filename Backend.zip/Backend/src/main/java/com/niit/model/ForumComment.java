package com.niit.model;

public class ForumComment {

}
