package com.niit.daoImpl;

import java.util.List;

import com.niit.dao.FriendDao;
import com.niit.model.Friend;

public class FriendDaoImpl implements FriendDao {

	public List<Friend> getMyFriends(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Friend> getMyFriend(int friendId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Friend get(int userId, int friendId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(Friend friend) {
		// TODO Auto-generated method stub

	}

	public void update(Friend friend) {
		// TODO Auto-generated method stub

	}

	public void delete(int userId, int friendId) {
		// TODO Auto-generated method stub

	}

	public List<Friend> getNewFriendRequests(int friendId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setOnline(int friendId) {
		// TODO Auto-generated method stub

	}

	public void setOffline(int friendId) {
		// TODO Auto-generated method stub

	}

}
