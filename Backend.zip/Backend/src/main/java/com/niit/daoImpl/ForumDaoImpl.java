package com.niit.daoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.dao.ForumDao;
import com.niit.model.Forum;
import com.niit.model.ForumComment;

@Repository("forumDAO")
@Transactional

public class ForumDaoImpl implements ForumDao {
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public boolean addForum(Forum forum) {// TC Compl
		try {
			sessionFactory.getCurrentSession().save(forum);
			System.out.println("forum Added");
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public boolean deleteForum(Forum forum) {// TC Compl
		sessionFactory.getCurrentSession().remove(forum);
		System.out.println("Forum Removed");
		return true;
	}

	@Transactional
	public boolean updateForum(Forum forum) {// TC Compl
		System.out.println("#######");
		sessionFactory.getCurrentSession().update(forum);
		System.out.println("Forum Updated");
		return true;
	}

	@Transactional
	public Forum getForum(int forumId) {// TC Compl
		Session session = sessionFactory.openSession();
		Forum forum = session.get(Forum.class, forumId);
		session.close();
		return forum;
	}

	@Transactional
	public boolean approveForum(Forum forum) {
		forum.setStatus("A");
		System.out.println("Forum Approved");
		sessionFactory.getCurrentSession().update(forum);
		return true;
	}

	@Transactional
	public boolean rejectForum(Forum forum) {
		forum.setStatus("NA");
		System.out.println("Forum Rejected");
		sessionFactory.getCurrentSession().update(forum);
		return true;
	}

	@Transactional
	public List<Forum> listForum(String forumusername) {
		System.out.println("List of username in forum");
		return sessionFactory.getCurrentSession()
				.createQuery("from Forum where forumname='" + forumusername + "'", Forum.class).getResultList();
		// return (List<Forum>) sessionFactory.getCurrentSession().get(Forum.class,
		// forumusername);
	}

	@Transactional
	public ForumComment getForumComment(int commentId) {
		try {
			Session session = sessionFactory.openSession();
			ForumComment forumComment = session.get(ForumComment.class, commentId);
			return forumComment;
		} catch (Exception e) {
			return null;
		}
	}

	@Transactional
	public List<ForumComment> listForumComments(int forumId) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from ForumComment where forumId=:forumId");
		query.setParameter("forumId", new Integer(forumId));
		@SuppressWarnings("unchecked")
		List<ForumComment> listForumComments = query.list();
		return listForumComments;
	}

	@Transactional
	public boolean addForumComment(ForumComment forumComment) {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(forumComment);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public boolean deleteForumComment(ForumComment forumComment) {
		try {
			sessionFactory.getCurrentSession().delete(forumComment);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

}
