package com.niit.daoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.dao.BlogDao;
import com.niit.model.Blog;
import com.niit.model.BlogComment;

@Repository("blogDAO")
@Transactional
public class BlogDaoImpl implements BlogDao {

	@Autowired
	SessionFactory sessionFactory;

	public boolean addBlog(Blog blog) {
		try {
			sessionFactory.getCurrentSession().save(blog);
			System.out.println("Blog Added");
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean deleteBlog(Blog blog) {
		sessionFactory.getCurrentSession().remove(blog);
		System.out.println("BlogRemoved");
		return true;
	}

	public boolean updateBlog(Blog blog) {
		System.out.println("******");
		sessionFactory.getCurrentSession().update(blog);
		System.out.println("Forum Updated");
		return true;
	}

	public Blog getBlog(int blogId) {
		Session session = sessionFactory.openSession();
		Blog blog = session.get(Blog.class, blogId);
		session.close();
		return blog;
	}

	@Transactional
	public boolean approveBlog(Blog blog) {
		blog.setStatus("A");
		sessionFactory.getCurrentSession().update(blog);
		return true;
	}

	@Transactional
	public boolean rejectBlog(Blog blog) {
		blog.setStatus("NA");
		sessionFactory.getCurrentSession().update(blog);
		return true;
	}

	public List<Blog> listBlog(String username) {
		System.out.println("List of users in Blog");
		return sessionFactory.getCurrentSession().createQuery("from Blog where username='" + username + "'", Blog.class)
				.getResultList();
	}

	@Transactional
	public boolean addBlogComment(BlogComment blogComment) {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(blogComment);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public boolean deleteBlogComment(BlogComment blogComment) {
		try {
			sessionFactory.getCurrentSession().delete(blogComment);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public BlogComment getBlogComment(int commentId) {

		try {
			Session session = sessionFactory.openSession();
			BlogComment blogComment = session.get(BlogComment.class, commentId);
			System.out.println(blogComment);
			return blogComment;
		} catch (Exception e) {
			return null;
		}
	}

	@Transactional
	public List<BlogComment> listBlogComments(int blogId) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BlogComment where blogId=:blogId");
		query.setParameter("blogId", new Integer(blogId));
		@SuppressWarnings("unchecked")
		List<BlogComment> listBlogComments = query.list();
		return listBlogComments;

	}

	public boolean incrementLike(Blog blog) {
		try {
			int likes = blog.getLikes();
			likes++;
			blog.setLikes(likes);
			sessionFactory.getCurrentSession().update(blog);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

}
