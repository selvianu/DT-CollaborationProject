package com.niit.daoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.niit.dao.UserDao;
import com.niit.model.User;

@Repository("userDao")
@Transactional
public class UserDaoImpl implements UserDao {
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public boolean addUser(User user) {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(user);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public boolean deleteUser(User user) {
		try {
			sessionFactory.getCurrentSession().delete(user);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public boolean updateUser(User user) {
		try {
			sessionFactory.getCurrentSession().update(user);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public User getUser(int userId) {
		try {
			System.out.println("############");
			Session session = sessionFactory.openSession();
			User user = session.get(User.class, userId);
			System.out.println("((((((()))))))))" + user.getUsername() + "((((())))))");

			return user;
		} catch (Exception e) {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<User> listUser(String username) {
		try {
			Session session = sessionFactory.openSession();
			session.beginTransaction();
			List<User> userList = new ArrayList<User>();
			Query query = session.createQuery("FROM User where username=:username").setString("username", username);
			userList = query.list();
			return userList;
		} catch (Exception e) {
			return null;
		}
	}

	public boolean checkLogin(User user) {
		try {
			Session session = sessionFactory.openSession();
			System.out.println("@@@@@@@@@");
			User user1 = session.createQuery("from User where username=:username and password=:password",User.class).setParameter("username", user.getUsername()).setParameter("password", user.getPassword()).getSingleResult();
			System.out.println("*********User" + user.getFirstname());
			// session.close();
			if (user1 == null) {
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			return false;
		}

	}

	@Transactional
	public boolean registerUser(User user) {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(user);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public boolean updateOnlineStatus(String status, User user) {

		try {
			user.setStatus(status);
			sessionFactory.getCurrentSession().update(user);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	@Transactional
	public User getUserByName(String username) {

		// User user = new User();

		try {
			System.out.println("############");
			Session session = sessionFactory.openSession();
			User user1 = session.createQuery("from User where username=:username", User.class)
					.setParameter("username", username).getSingleResult();
			// System.out.println("*********Query" + query);

			if (user1 != null) {
				System.out.println("((((((()))))))))" + user1.getUsername() + "((((())))))");
				return user1;
			} else
				System.out.println("user name is null");
			return null;

		} catch (Exception e) {
			System.out.println("exception!..");
			return null;
		}

	}

	@Transactional
	public List<User> listUsers() {
		try {
			Session session = sessionFactory.openSession();
			session.beginTransaction();
			List<User> userList = new ArrayList<User>();
			Query query = session.createQuery("FROM User");
			userList = query.list();
			return userList;
		} catch (Exception e) {
			return null;
		}
	}

}
