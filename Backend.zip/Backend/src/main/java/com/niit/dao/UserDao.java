package com.niit.dao;

import java.util.ArrayList;
import java.util.List;

import com.niit.model.User;

public interface UserDao {

	List<User> getAllUsers();

	User getUserById(int userId);

	boolean addUser(User user);

	boolean updateUser(User user);

	boolean deleteUser(User user);

	boolean userExists(String name);

	ArrayList<User> requestFriend(int user_id);

	ArrayList<User> userrequests();

	User getUserbyemail_id(String email_id);

	void approveusers(User user);

	void rejectusers(User user);

	boolean checkLogin(User user);

	void updateOnlineStatus(User tempuser);


}
