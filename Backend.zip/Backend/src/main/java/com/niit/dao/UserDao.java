package com.niit.dao;

import java.util.List;

import com.niit.model.User;

public interface UserDao {

	public boolean addUser(User user);

	public boolean deleteUser(User user);

	public boolean updateUser(User user);

	public User getUser(int id);

	public boolean checkLogin(User user);

	public boolean updateOnlineStatus(String status, User username);

	public boolean registerUser(User user);

	public User getUserByName(String username);

	public List<User> listUsers();

}
