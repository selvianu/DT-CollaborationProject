package com.niit.DBConfig;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.daoImpl.BlogDaoImpl;
import com.niit.daoImpl.ForumDaoImpl;
import com.niit.daoImpl.JobDaoImpl;
import com.niit.daoImpl.ProfileUpdateDAO;
import com.niit.daoImpl.UserDaoImpl;

@Configuration
@EnableTransactionManagement
@ComponentScan("com.niit")

public class dbConfig {
	
	
	@Bean(name = "dataSource")
	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		dataSource.setUsername("hr");
		dataSource.setPassword("hr");
		System.out.println("Datasource Connected");
		return dataSource;

	}

	@Bean(name = "sessionFactory")
	public SessionFactory getSessionFactory() {
		Properties hibernateProp = new Properties();
		hibernateProp.put("hibernate.hbm2ddl.auto", "update");
		hibernateProp.put("hibernate.show_sql", "true");
		hibernateProp.put("hibernate.format_sql", "true");
		hibernateProp.put("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
		LocalSessionFactoryBuilder sessionFactoryBuilder = new LocalSessionFactoryBuilder(getDataSource());
		sessionFactoryBuilder.scanPackages("com.niit");
		sessionFactoryBuilder.addProperties(hibernateProp);
		SessionFactory sessionFactory = sessionFactoryBuilder.buildSessionFactory();
		System.out.println("SessionFactory Object created");
		return sessionFactory;
	}

	/*
	 * @Bean(name = "blogdao") public BlogDao getBlogDao() {
	 * System.out.println("-----------BlogDao method--------"); return new
	 * BlogDaoImpl();
	 * 
	 * }
	 */
	@Bean(name = "blogDAOImpl")
	public BlogDaoImpl getBlogDAO(SessionFactory sf) {
		return new BlogDaoImpl();
	}

	@Bean(name = "forumDAOImpl")
	public ForumDaoImpl getForumDAO(SessionFactory sf) {
		return new ForumDaoImpl();
	}

	@Bean(name = "jobDAOImpl")
	public JobDaoImpl getJobgDAO(SessionFactory sf) {
		return new JobDaoImpl();
	}

	@Bean(name = "userDAOImpl")
	public UserDaoImpl getUserDAO(SessionFactory sf) {
		return new UserDaoImpl();
	}

	@Bean(name = "profileUpdateDAO")
	public ProfileUpdateDAO getProfilePictureDAO(SessionFactory sf) {
		return new ProfileUpdateDAO(sf);
	}

	@Bean("transactionManager")
	public HibernateTransactionManager getHibernateTransactionManager(SessionFactory sessionFactory) {
		return new HibernateTransactionManager(sessionFactory);

	}

}
