/**
 * UserController for login
 */
myApp.controller("UserController", function($scope, $http, $location,
		$rootScope, $cookieStore) {
	$scope.user = {
		loginname : '',
		password : '',
		role : '',
		username : '',
		emailId : '',
		mobileNo : '',
		address : '',
		isOnline : ''
	};
	$scope.userProfile = {
		loginname : '',
		image : ''
	};
	myApp.config([ '$qProvider', function($qProvider) {
		$qProvider.errorOnUnhandledRejections(false);
	} ]);

	$rootScope.login = function() {
		console.log("Logging Function");
		console.log($scope.user.loginname);
		$http.post('http://localhost:8045/MiddleWare_Collaboration/login',
				$scope.user).then(function(response) {
			console.log(response.status);
			// console.log(response.loginname);
			$scope.user = response.data;
			$rootScope.currentUser = response.data;
			$cookieStore.put('user', response.data);
			console.log($rootScope.currentUser.role);
			if ($rootScope.currentUser.role == "ROLE_ADMIN") {
				console.log('AdminPage');
			} else {
				console.log('UserPage');
			}
			$location.path("/");
		});
	};

	$rootScope.logout = function() {
		console.log('Logout Function');
		delete $rootScope.currentUser;
		$cookieStore.remove('userDetails');
		$location.path("/");
	}

});